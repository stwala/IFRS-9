from django.apps import AppConfig


class FinancialStatementsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'financial_statements'
